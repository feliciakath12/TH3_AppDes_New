﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W3_Take_Home_NEW
{
    public partial class Form2 : Form
    {
        //Felicia / 002
        public static List<int>listSaldo2 = new List<int>();
        public static List<string> listUsername = new List<string>();
        public static List<string> listPassword = new List<string>();
        bool cekKembar = false;
        public Form2()
        {
            InitializeComponent();
        }

        private void btn_Register_Click(object sender, EventArgs e)
        {
            foreach (string usernameKembar in listUsername)
            {
                if (tb_Username.Text == usernameKembar)
                {
                    cekKembar = true;
                }
            }

            if (cekKembar == true)
            {
                MessageBox.Show("Username has been used");
            }
            if (cekKembar == false)
            {
                MessageBox.Show("Register successful");
                listSaldo2.Add(0);
                listUsername.Add(tb_Username.Text);
                listPassword.Add(tb_Password.Text);
            }

            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();

        }
    }
}
