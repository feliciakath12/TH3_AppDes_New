﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W3_Take_Home_NEW
{
    public partial class Form4 : Form
    {
        //Felicia / 002
        public static List<int> listSaldo4 = new List<int>(); 
        int intDeposit;
        string hasilakhirD;
        int index;

        public Form4()
        {
            InitializeComponent();
            listSaldo4 = Form2.listSaldo2;
            index = Form1.index;
        }

        private void btn_Deposit_Click(object sender, EventArgs e)
        {
            ubahInt();

            if (intDeposit <= 0)
            {
                MessageBox.Show("Deposit Amount Can't be Less Than 1");
                Form3 f3 = new Form3();
                f3.Show();
                this.Hide();
            }
            else if (intDeposit > 0)
            {
                MessageBox.Show("Successfully Add Deposit");
                JumlahD();
                ubahString();
                ubahFormat();

                Form3 f3 = new Form3();
                f3.Show();
                this.Hide();
            }
        }

        private void ubahInt()
        {
            intDeposit = Convert.ToInt32(tb_InputDeposit.Text);
        }

        private void JumlahD()
        {
            listSaldo4[index] += intDeposit;
        }

        private void ubahString()
        {
            hasilakhirD = listSaldo4[index].ToString();
        }

        private void ubahFormat()
        {
            CultureInfo culture = new CultureInfo("id-ID");
            hasilakhirD = Decimal.Parse(hasilakhirD.ToString()).ToString("C", culture);
        }

        private void btn_LogOut_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Log Out Berhasil");
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }
    }
}
