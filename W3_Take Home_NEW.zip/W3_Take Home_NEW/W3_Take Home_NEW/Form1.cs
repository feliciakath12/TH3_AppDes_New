﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W3_Take_Home_NEW
{
    public partial class Form1 : Form
    {
        //Felicia / 002
        public static int index;
        public static List<string> simpanUsername = new List<string>();
        List<string> simpanPassword = new List<string>();
        bool cek = false;
       
        public Form1()
        {
            InitializeComponent();
            simpanUsername = Form2.listUsername;
            simpanPassword = Form2.listPassword;
        }

        private void btn_Register_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
            this.Hide();
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < simpanUsername.Count(); i++)
            {
                if (tb_Username.Text == simpanUsername[i] && tb_Password.Text == simpanPassword[i])
                {
                    cek = true;
                    index = i;
                }
                else if (simpanUsername.Count() == 0)
                {
                    cek = false;
                }
            }

            if (cek == true)
            {
                MessageBox.Show("Login Successful");
                Form3 f3 = new Form3();
                f3.Show();
                this.Hide();
            }
            else if (cek == false)
            {
                MessageBox.Show("Username and Password not found!");
            }
        }
    }
}
