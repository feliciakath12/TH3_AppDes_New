﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W3_Take_Home_NEW
{
    public partial class Form3 : Form
    {
        //Felicia / 002
        List<int> listSaldo3 = new List<int>();
        public static string hasilRupiah;
        int index;

        public Form3()
        {
            InitializeComponent();
            index = Form1.index;
            listSaldo3 = Form2.listSaldo2;

            hasilRupiah = string.Format(CultureInfo.CreateSpecificCulture("id-ID"), "{0:C2}", listSaldo3[index]);
            lb_RpBerapa.Text = hasilRupiah;
        }
    

        private void btn_Deposit_Click(object sender, EventArgs e)
        {
            Form4 f4 = new Form4();
            f4.Show();
            this.Hide();
        }

        private void btn_LogOut_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Log Out Berhasil");
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void btn_Withdraw_Click(object sender, EventArgs e)
        {
            Form5 f5 = new Form5();
            f5.Show();
            this.Hide();
        }
    }
}
