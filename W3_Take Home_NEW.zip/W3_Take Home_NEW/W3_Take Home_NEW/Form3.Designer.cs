﻿namespace W3_Take_Home_NEW
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Deposit = new System.Windows.Forms.Button();
            this.lb_RpBerapa = new System.Windows.Forms.Label();
            this.lb_Balance = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_LogOut = new System.Windows.Forms.Button();
            this.btn_Withdraw = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_Deposit
            // 
            this.btn_Deposit.Location = new System.Drawing.Point(231, 245);
            this.btn_Deposit.Name = "btn_Deposit";
            this.btn_Deposit.Size = new System.Drawing.Size(113, 34);
            this.btn_Deposit.TabIndex = 21;
            this.btn_Deposit.Text = "Deposit";
            this.btn_Deposit.UseVisualStyleBackColor = true;
            this.btn_Deposit.Click += new System.EventHandler(this.btn_Deposit_Click);
            // 
            // lb_RpBerapa
            // 
            this.lb_RpBerapa.AutoSize = true;
            this.lb_RpBerapa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_RpBerapa.Location = new System.Drawing.Point(226, 199);
            this.lb_RpBerapa.Name = "lb_RpBerapa";
            this.lb_RpBerapa.Size = new System.Drawing.Size(26, 29);
            this.lb_RpBerapa.TabIndex = 18;
            this.lb_RpBerapa.Text = "0";
            // 
            // lb_Balance
            // 
            this.lb_Balance.AutoSize = true;
            this.lb_Balance.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Balance.Location = new System.Drawing.Point(135, 206);
            this.lb_Balance.Name = "lb_Balance";
            this.lb_Balance.Size = new System.Drawing.Size(75, 22);
            this.lb_Balance.TabIndex = 17;
            this.lb_Balance.Text = "Balance";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(140, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(224, 52);
            this.label1.TabIndex = 16;
            this.label1.Text = "UC BANK";
            // 
            // btn_LogOut
            // 
            this.btn_LogOut.Location = new System.Drawing.Point(305, 122);
            this.btn_LogOut.Name = "btn_LogOut";
            this.btn_LogOut.Size = new System.Drawing.Size(144, 36);
            this.btn_LogOut.TabIndex = 22;
            this.btn_LogOut.Text = "Log Out";
            this.btn_LogOut.UseVisualStyleBackColor = true;
            this.btn_LogOut.Click += new System.EventHandler(this.btn_LogOut_Click);
            // 
            // btn_Withdraw
            // 
            this.btn_Withdraw.Location = new System.Drawing.Point(231, 286);
            this.btn_Withdraw.Name = "btn_Withdraw";
            this.btn_Withdraw.Size = new System.Drawing.Size(113, 35);
            this.btn_Withdraw.TabIndex = 23;
            this.btn_Withdraw.Text = "Withdraw";
            this.btn_Withdraw.UseVisualStyleBackColor = true;
            this.btn_Withdraw.Click += new System.EventHandler(this.btn_Withdraw_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_Withdraw);
            this.Controls.Add(this.btn_LogOut);
            this.Controls.Add(this.btn_Deposit);
            this.Controls.Add(this.lb_RpBerapa);
            this.Controls.Add(this.lb_Balance);
            this.Controls.Add(this.label1);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Deposit;
        private System.Windows.Forms.Label lb_RpBerapa;
        private System.Windows.Forms.Label lb_Balance;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_LogOut;
        private System.Windows.Forms.Button btn_Withdraw;
    }
}