﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W3_Take_Home_NEW
{
    public partial class Form5 : Form
    {
        //Felicia / 002
        List<int> listSaldo5 = new List<int>();
        int index;
        int intWithdraw;
        string hasilakhirW;
        string hasilRupiah5;

        public Form5()
        {
            InitializeComponent();
            hasilRupiah5 = Form3.hasilRupiah;
            index = Form1.index;
            listSaldo5 = Form2.listSaldo2;

            lb_RpBerapa.Text = hasilRupiah5;
        }

        private void btn_Withdraw_Click(object sender, EventArgs e)
        {
            ubahInt();
            if (intWithdraw <= 0 || intWithdraw >= listSaldo5[index])
            {
                MessageBox.Show("Withdraw Failed. Not Enough Balanced");
                Form3 f3 = new Form3();
                f3.Show();
                this.Hide();
            }
            else if (intWithdraw <= listSaldo5[index])
            {
                MessageBox.Show("Successfully Add Withdraw");

                JumlahW();
                ubahString();
                ubahFormat();
                Form4.listSaldo4[index] = this.listSaldo5[index];

                Form3 f3 = new Form3();
                f3.Show();
                this.Hide();
            }
        }

        private void ubahInt()
        {
            intWithdraw = Convert.ToInt32(tb_InputWithdraw.Text);
        }

        private void JumlahW()
        {
            listSaldo5[index] -= intWithdraw;
        }

        private void ubahString()
        {
            hasilakhirW = listSaldo5[index].ToString();
        }

        private void ubahFormat()
        {
            CultureInfo culture = new CultureInfo("id-ID");
            hasilakhirW = Decimal.Parse(hasilakhirW.ToString()).ToString("C", culture);
        }

        private void btn_LogOut_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Log Out Berhasil");
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }
    }
}