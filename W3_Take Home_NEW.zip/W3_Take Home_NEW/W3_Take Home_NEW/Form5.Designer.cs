﻿namespace W3_Take_Home_NEW
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_InputWithdraw = new System.Windows.Forms.TextBox();
            this.btn_LogOut = new System.Windows.Forms.Button();
            this.btn_Withdraw = new System.Windows.Forms.Button();
            this.lb_InputWithdraw = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lb_RpBerapa = new System.Windows.Forms.Label();
            this.lb_Balance = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tb_InputWithdraw
            // 
            this.tb_InputWithdraw.Location = new System.Drawing.Point(179, 281);
            this.tb_InputWithdraw.Name = "tb_InputWithdraw";
            this.tb_InputWithdraw.Size = new System.Drawing.Size(165, 26);
            this.tb_InputWithdraw.TabIndex = 34;
            // 
            // btn_LogOut
            // 
            this.btn_LogOut.Location = new System.Drawing.Point(285, 118);
            this.btn_LogOut.Name = "btn_LogOut";
            this.btn_LogOut.Size = new System.Drawing.Size(144, 36);
            this.btn_LogOut.TabIndex = 33;
            this.btn_LogOut.Text = "Log Out";
            this.btn_LogOut.UseVisualStyleBackColor = true;
            this.btn_LogOut.Click += new System.EventHandler(this.btn_LogOut_Click);
            // 
            // btn_Withdraw
            // 
            this.btn_Withdraw.Location = new System.Drawing.Point(207, 321);
            this.btn_Withdraw.Name = "btn_Withdraw";
            this.btn_Withdraw.Size = new System.Drawing.Size(113, 34);
            this.btn_Withdraw.TabIndex = 32;
            this.btn_Withdraw.Text = "Withdraw";
            this.btn_Withdraw.UseVisualStyleBackColor = true;
            this.btn_Withdraw.Click += new System.EventHandler(this.btn_Withdraw_Click);
            // 
            // lb_InputWithdraw
            // 
            this.lb_InputWithdraw.AutoSize = true;
            this.lb_InputWithdraw.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_InputWithdraw.Location = new System.Drawing.Point(168, 244);
            this.lb_InputWithdraw.Name = "lb_InputWithdraw";
            this.lb_InputWithdraw.Size = new System.Drawing.Size(214, 22);
            this.lb_InputWithdraw.TabIndex = 31;
            this.lb_InputWithdraw.Text = "Input Withdrawal Amount:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(120, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(224, 52);
            this.label1.TabIndex = 30;
            this.label1.Text = "UC BANK";
            // 
            // lb_RpBerapa
            // 
            this.lb_RpBerapa.AutoSize = true;
            this.lb_RpBerapa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_RpBerapa.Location = new System.Drawing.Point(246, 204);
            this.lb_RpBerapa.Name = "lb_RpBerapa";
            this.lb_RpBerapa.Size = new System.Drawing.Size(128, 29);
            this.lb_RpBerapa.TabIndex = 36;
            this.lb_RpBerapa.Text = "Rp Berapa";
            // 
            // lb_Balance
            // 
            this.lb_Balance.AutoSize = true;
            this.lb_Balance.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Balance.Location = new System.Drawing.Point(136, 209);
            this.lb_Balance.Name = "lb_Balance";
            this.lb_Balance.Size = new System.Drawing.Size(75, 22);
            this.lb_Balance.TabIndex = 35;
            this.lb_Balance.Text = "Balance";
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lb_RpBerapa);
            this.Controls.Add(this.lb_Balance);
            this.Controls.Add(this.tb_InputWithdraw);
            this.Controls.Add(this.btn_LogOut);
            this.Controls.Add(this.btn_Withdraw);
            this.Controls.Add(this.lb_InputWithdraw);
            this.Controls.Add(this.label1);
            this.Name = "Form5";
            this.Text = "Form5";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_InputWithdraw;
        private System.Windows.Forms.Button btn_LogOut;
        private System.Windows.Forms.Button btn_Withdraw;
        private System.Windows.Forms.Label lb_InputWithdraw;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lb_RpBerapa;
        private System.Windows.Forms.Label lb_Balance;
    }
}